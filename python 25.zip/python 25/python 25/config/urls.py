from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from notes.views import NoteViewSet

router = routers.DefaultRouter()
router.register(r'notes', NoteViewSet, basename='note')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('notes.urls')),               # фронтенд страницы заметок + register
    path('accounts/', include('django.contrib.auth.urls')),  # login/logout
    path('api/', include(router.urls)),           # DRF API роуты
]
