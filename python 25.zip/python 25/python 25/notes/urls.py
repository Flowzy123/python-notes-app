from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    NoteListView,
    NoteDetailView,
    NoteCreateView,
    NoteUpdateView,
    NoteDeleteView,
    register_view,
    NoteViewSet  # DRF ViewSet
)

# Роутер для DRF API
router = DefaultRouter()
router.register(r'api/notes', NoteViewSet, basename='note')

urlpatterns = [
    path('', NoteListView.as_view(), name='note_list'),
    path('note/<int:pk>/', NoteDetailView.as_view(), name='note_detail'),
    path('note/create/', NoteCreateView.as_view(), name='note_create'),
    path('note/<int:pk>/update/', NoteUpdateView.as_view(), name='note_update'),
    path('note/<int:pk>/delete/', NoteDeleteView.as_view(), name='note_delete'),
    path('register/', register_view, name='register'),
    
    # Подключаем DRF API
    path('', include(router.urls)),
]
