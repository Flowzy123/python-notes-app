from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

from rest_framework import viewsets, permissions
from .models import Note
from .serializers import NoteSerializer

# ===============================
# API DRF
# ===============================

class IsOwner(permissions.BasePermission):
    """Права: только владелец может редактировать/удалять."""
    def has_object_permission(self, request, view, obj):
        return obj.owner == request.user

class NoteViewSet(viewsets.ModelViewSet):
    serializer_class = NoteSerializer
    permission_classes = [permissions.IsAuthenticated, IsOwner]

    def get_queryset(self):
        user = self.request.user
        qs = Note.objects.filter(owner=user).order_by('-updated_at')
        status = self.request.query_params.get('status')
        if status in ('draft', 'published'):
            qs = qs.filter(status=status)
        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(title__icontains=search)
        return qs

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

# ===============================
# CBV для веб (Django generic views)
# ===============================

class OwnerMixin(UserPassesTestMixin):
    """Ограничение: только автор может редактировать/удалять"""
    def test_func(self):
        obj = self.get_object()
        return obj.owner == self.request.user

class NoteListView(LoginRequiredMixin, ListView):
    model = Note
    template_name = 'notes/note_list.html'
    context_object_name = 'notes'
    paginate_by = 10

    def get_queryset(self):
        qs = Note.objects.filter(owner=self.request.user).order_by('-updated_at')
        status = self.request.GET.get('status')
        if status in ('draft', 'published'):
            qs = qs.filter(status=status)
        search = self.request.GET.get('search')
        if search:
            qs = qs.filter(title__icontains=search)
        return qs

class NoteDetailView(LoginRequiredMixin, OwnerMixin, DetailView):
    model = Note
    template_name = 'notes/note_detail.html'
    context_object_name = 'note'

class NoteCreateView(LoginRequiredMixin, CreateView):
    model = Note
    template_name = 'notes/note_form.html'
    fields = ['title', 'body', 'status', 'tags']  # <-- исправил content -> body и добавил tags
    success_url = reverse_lazy('note_list')

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class NoteUpdateView(LoginRequiredMixin, OwnerMixin, UpdateView):
    model = Note
    template_name = 'notes/note_form.html'
    fields = ['title', 'body', 'status', 'tags']  # <-- тоже исправил
    success_url = reverse_lazy('note_list')

class NoteDeleteView(LoginRequiredMixin, OwnerMixin, DeleteView):
    model = Note
    template_name = 'notes/note_confirm_delete.html'
    success_url = reverse_lazy('note_list')

# ===============================
# Регистрация пользователя
# ===============================

def register_view(request):
    """Функция регистрации через форму"""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('note_list')
    else:
        form = UserCreationForm()
    return render(request, 'notes/register.html', {'form': form})
