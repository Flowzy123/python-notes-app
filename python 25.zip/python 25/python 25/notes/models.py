from django.db import models
from django.conf import settings
from taggit.managers import TaggableManager  # опция, если используешь django-taggit

class Note(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Черновик'),
        ('published', 'Опубликовано'),
    ]

    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notes')
    title = models.CharField(max_length=200)
    body = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField(auto_now_add=True)   # ставится автоматически при создании
    updated_at = models.DateTimeField(auto_now=True)       # обновляется при сохранении

    tags = TaggableManager(blank=True)  # опционально

    def __str__(self):
        return self.title
